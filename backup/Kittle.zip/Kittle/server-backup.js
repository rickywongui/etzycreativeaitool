// server.js
// Node + Express backend to proxy AI requests to OpenAI securely.
// Usage: set OPENAI_API_KEY in .env and run `node server.js` (or use nodemon)

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
// import axios from 'axios';

import path from "path";
import { fileURLToPath } from "url";
import OpenAI from "openai";

const openai = new OpenAI({
    apiKey: "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"
});



const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// OPTIONAL – only if you want backend to serve your HTML file
app.use(express.static(path.join(__dirname, "public")));

app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});


console.log("Loaded API key:", !!process.env.OPENAI_API_KEY);

const OPENAI_KEY = process.env.OPENAI_API_KEY;
if (!OPENAI_KEY) {
    console.error('Missing OPENAI_API_KEY in env');
    process.exit(1);
}

const OPENAI_URL = 'https://api.openai.com/v1/chat/completions';
const DEFAULT_MODEL = 'gpt-4o-mini'; // stable general-purpose model

async function callOpenAI(messages, max_tokens = 1200, jsonSchemaWrapper = null) {
    try {
        const payload = {
            model: DEFAULT_MODEL || "gpt-4o-mini",
            messages,
            max_tokens,
            temperature: 0.7
        };

        // Only attach response_format when explicitly passed
        if (jsonSchemaWrapper) {
            payload.response_format = {
                type: "json_schema",
                json_schema: jsonSchemaWrapper
            };
        }

        const resp = await openai.chat.completions.create(payload);
        return resp;
    } catch (err) {
        console.error("OpenAI SDK error:", err?.response?.data ?? err.message);
        throw err;
    }
}



/* ---------- Endpoints ---------- */

/*
POST /api/ai/keywords
Body: { niche: "dog mom" }
Response: { keywords: [ ... ] }
*/
app.post('/api/ai/keywords', async (req, res) => {
    try {
        const { niche } = req.body;
        if (!niche) return res.status(400).json({ error: 'Missing niche' });

        const system = `You are an expert ecommerce & marketplace researcher.`;
        const user = `Given the niche "${niche}", produce:
1) A list of 25 SEO-friendly keyword phrases (short phrases, 2-4 words) that would perform well on Etsy or Print-on-Demand marketplaces.
2) For each phrase return an estimated competition score on a 1-10 scale (1 low competition, 10 very high).
Return JSON only in the format:
{
  "keywords": [
    {"phrase":"...","score":4},
    ...
  ]
}`;

        const data = await callOpenAI([
            { role: 'system', content: system },
            { role: 'user', content: user }
        ], 700);

        // Extract assistant text and try to parse JSON
        const text = data.choices?.[0]?.message?.content ?? '';
        let parsed = null;
        try { parsed = JSON.parse(text); } catch (e) {
            // If assistant did not return pure JSON, try to extract JSON substring
            const m = text.match(/\\{[\\s\\S]*\\}/);
            if (m) parsed = JSON.parse(m[0]);
        }

        if (!parsed || !parsed.keywords) {
            return res.status(500).json({ error: 'OpenAI returned unexpected format', raw: text });
        }

        res.json(parsed);
    } catch (err) {
        console.error(err?.response?.data ?? err.message);
        res.status(500).json({ error: 'AI error', detail: err?.response?.data ?? err.message });
    }
});

/*
POST /api/ai/ideas
Body: { keyword: "cat" }
Response: { ideas: [ ... ] }
*/
app.post('/api/ai/ideas', async (req, res) => {
    try {
        const { keyword } = req.body;
        if (!keyword) return res.status(400).json({ error: 'Missing keyword' });

        const system = `You are a creative product copywriter that writes short, catchy phrases for T-shirts, stickers and posters.`;
        const user = `
        Create 40 unique design phrases for the keyword "${keyword}". 
        Group them into categories: "cute", "funny", "vintage", "minimal", "witty". 
        Return *pure JSON only*. 
        No explanations. 
        No code block fences like \`\`\`. 
        JSON format:
        {"ideas":{"cute":[],"funny":[],"vintage":[],"minimal":[],"witty":[]}}
        `;


        const data = await callOpenAI([
            { role: 'system', content: system },
            { role: 'user', content: user }
        ], 900);

        let text = data.choices?.[0]?.message?.content ?? '';

        text = text
            .replace(/```json/g, '')
            .replace(/```/g, '')
            .trim();

        let parsed = null;
        try { parsed = JSON.parse(text); } catch (e) {
            const m = text.match(/\\{[\\s\\S]*\\}/);
            if (m) parsed = JSON.parse(m[0]);
        }

        if (!parsed || !parsed.ideas) {
            return res.status(500).json({ error: 'OpenAI returned unexpected format', raw: text });
        }
        res.json(parsed);
    } catch (err) {
        console.error(err?.response?.data ?? err.message);
        res.status(500).json({ error: 'AI error', detail: err?.response?.data ?? err.message });
    }
});

/*
POST /api/ai/listing
Body: { titleHint: "", features: "e.g. png, svg", keywords: ["a","b"] }
Response: { title: "", description: "", tags: [] }
*/
app.post('/api/ai/listing', async (req, res) => {
    try {
        const { titleHint = '', features = '', keywords = [] } = req.body;
        const system = `You are an expert Etsy seller and SEO copywriter.`;
        const user = `Create an optimized Etsy listing for a digital product.
Input:
titleHint: ${titleHint}
features: ${features}
keywords: ${JSON.stringify(keywords)}
Return JSON:
{"title":"...","description":"...","tags":["...","..."]} Make description ~200-350 words and include suggested usage, included files, and short SEO intro. Return JSON only.`;

        const data = await callOpenAI([
            { role: 'system', content: system },
            { role: 'user', content: user }
        ], 1000);

        const text = data.choices?.[0]?.message?.content ?? '';
        let parsed = null;
        try { parsed = JSON.parse(text); } catch (e) {
            const m = text.match(/\\{[\\s\\S]*\\}/);
            if (m) parsed = JSON.parse(m[0]);
        }

        if (!parsed || !parsed.title) {
            return res.status(500).json({ error: 'OpenAI returned unexpected format', raw: text });
        }
        res.json(parsed);
    } catch (err) {
        console.error(err?.response?.data ?? err.message);
        res.status(500).json({ error: 'AI error', detail: err?.response?.data ?? err.message });
    }
});

/*
POST /api/ai/mockup-prompt
Body: { productType: "t-shirt", styleHint: "vintage", color: "cream", keyword: "dog mom" }
Response: { prompt: "..." }
*/
app.post('/api/ai/mockup-prompt', async (req, res) => {
    try {
        const { productType = 't-shirt', styleHint = '', color = '', keyword = '' } = req.body;
        const system = `You are a creative art director who writes short, clear prompts for text-to-image models to create product mockups.`;
        const user = `Write 5 short, actionable text prompts for generating lifestyle mockups for a ${productType} design using keyword "${keyword}" and style "${styleHint}" on ${color} background. Output JSON: {"prompts":["...","..."]}`;

        const data = await callOpenAI([
            { role: 'system', content: system },
            { role: 'user', content: user }
        ], 400);

        const text = data.choices?.[0]?.message?.content ?? '';
        let parsed = null;
        try { parsed = JSON.parse(text); } catch (e) {
            const m = text.match(/\\{[\\s\\S]*\\}/);
            if (m) parsed = JSON.parse(m[0]);
        }

        if (!parsed || !parsed.prompts) {
            return res.status(500).json({ error: 'OpenAI returned unexpected format', raw: text });
        }
        res.json(parsed);
    } catch (err) {
        console.error(err?.response?.data ?? err.message);
        res.status(500).json({ error: 'AI error', detail: err?.response?.data ?? err.message });
    }
});


/*
POST /api/ai/filename
Body: { filename: "cat lover design.png", keywords: ["cat","vintage"] }
Response: { filename: "..." }
*/
app.post('/api/ai/filename', async (req, res) => {
    try {
        const { filename = '', keywords = [] } = req.body;
        const system = `You are a helpful assistant that turns filenames into SEO-friendly filenames for Etsy digital products.`;
        const user = `Input filename: "${filename}". keywords: ${JSON.stringify(keywords)}.
Return a single-line JSON: {"filename":"<seo-friendly-filename-with-hyphens-and-keywords>.png"}. Keep extension same as input.`;

        const data = await callOpenAI([
            { role: 'system', content: system },
            { role: 'user', content: user }
        ], 200);

        const text = data.choices?.[0]?.message?.content ?? '';
        let parsed = null;
        try { parsed = JSON.parse(text); } catch (e) {
            const m = text.match(/\\{[\\s\\S]*\\}/);
            if (m) parsed = JSON.parse(m[0]);
        }

        if (!parsed || !parsed.filename) {
            return res.status(500).json({ error: 'OpenAI returned unexpected format', raw: text });
        }
        res.json(parsed);
    } catch (err) {
        console.error(err?.response?.data ?? err.message);
        res.status(500).json({ error: 'AI error', detail: err?.response?.data ?? err.message });
    }
});


/* health */


/*
POST /api/ai/trends
Body:  {}
Response: { trends: [ ... ] }
*/
app.post('/api/ai/trends', async (req, res) => {
    try {

        const trendSchema = {
            name: "TrendList",
            schema: {
                type: "object",
                properties: {
                    trends: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                event: { type: "string" },
                                date: { type: "string" },
                                region_or_scope: { type: "string" },
                                why: { type: "string" },
                                styles: {
                                    type: "array",
                                    items: { type: "string" }
                                },
                                ideas: {
                                    type: "array",
                                    items: { type: "string" }
                                }
                            },
                            required: ["event", "date", "region_or_scope", "why", "styles", "ideas"]
                        }
                    }
                },
                required: ["trends"]
            }
        };

        const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            response_format: {
                type: "json_schema",
                json_schema: trendSchema
            },
            messages: [
                {
                    role: "system",
                    content: "You generate perfect JSON for POD trend analysis."
                },
                {
                    role: "user",
                    content: `
                  Today's date: ${new Date().toISOString().split("T")[0]}

Generate EXACTLY 10 upcoming dates for Print-on-Demand (POD) creators.

🚨 ABSOLUTE TIME CONSTRAINT (DO NOT VIOLATE):
- ONLY include events occurring from TODAY up to 60 days from TODAY.
- DO NOT include events beyond this 60-day window under any circumstance.
- DO NOT include events in later months even if they are important.
- DO NOT include events in later years.
- If fewer than 10 globally significant events exist in this window, return fewer than 10.

EVENT SELECTION PRIORITY (ONLY WITHIN THIS WINDOW):
1️⃣ UN / UNESCO / globally recognized international days  
   (e.g. International Women’s Day, World Environment Day, LGBTQ+ Pride days)
2️⃣ Major public holidays (USA, EU, UK, CA, AU)
3️⃣ Widely observed cultural or religious events
4️⃣ Awareness & advocacy days with strong POD relevance
5️⃣ Commercial POD opportunities

STRICT RULES:
- NO events beyond 60 days from TODAY.
- NO year jumps.
- NO placeholder or filler events.
- ALL dates must be real and verifiable.
- Sort events strictly by date ascending.
- If an event already passed this year, DO NOT include it.

FOR EACH EVENT INCLUDE:
- event
- date (YYYY-MM-DD)
- region_or_scope
- why
- styles (array)
- ideas (array)

OUTPUT:
Return JSON ONLY.
No explanations.
No markdown.

{
  "trends": [
    {
      "event": "",
      "date": "",
      "region_or_scope": "",
      "why": "",
      "styles": [],
      "ideas": []
    }
  ]
}

                    `
                }

            ],
            max_tokens: 2000,
            temperature: 0.3
        });

        const json = response.choices[0].message.content;
        res.json(JSON.parse(json));

    } catch (err) {
        console.error("Trend Error:", err);
        res.status(500).json({
            error: "AI error",
            detail: err?.response?.data ?? err.message
        });
    }
});


/*
POST /api/ai/predict-trends
Body:
{
    "niches": ["dog mom", "teacher", "anime"]
}
Response:
{
  "predictions": [...]
}
*/
app.post('/api/ai/predict-trends', async (req, res) => {
    try {
        const niches = req.body.niches || [];

        const system = `
You are an expert in POD (Print On Demand), e-commerce seasonal trends, Etsy SEO, holiday cycles, 
consumer psychology, and trend forecasting.`;

        const user = `
Predict upcoming POD trends using a HYBRID model:
1. Global trend predictions  
2. Holiday season predictions  
3. Predictions based on these user niches: ${JSON.stringify(niches)}

IMPORTANT RULES:
- Return ONLY valid JSON.
- Arrays must contain ONLY strings.
- No trailing commas.
- No markdown.
- No commentary.
- No bullet points like "-" or "*".
- No line breaks inside array values.
- Your entire output MUST match this schema EXACTLY:

{
  "predictions": [
    {
      "trend": "string",
      "category": "global | holiday | user",
      "score": 0,
      "why": "string",
      "deadline": "string",
      "designStyles": ["string"],
      "productIdeas": ["string"],
      "actionPlan": "string"
    }
  ]
}

Do not include any text before or after this JSON object.
`;


        const data = await callOpenAI([
            { role: "system", content: system },
            { role: "user", content: user }
        ], 1200);

        let text = data.choices?.[0]?.message?.content ?? "";

        // clean accidental formatting
        // Fix common AI JSON issues
        text = text
            .replace(/,\s*]/g, "]")          // remove trailing commas
            .replace(/,\s*}/g, "}")          // remove trailing object commas
            .replace(/“/g, '"')              // replace fancy quotes
            .replace(/”/g, '"')
            .replace(/‘/g, "'")
            .replace(/’/g, "'")
            .replace(/[\r\n]+/g, " ");       // flatten accidental line breaks inside strings


        let json = null;

        try {
            json = JSON.parse(text);
        } catch (e) {
            // Try extracting the JSON object only
            const match = text.match(/\{[\s\S]*\}/);
            if (match) {
                try {
                    json = JSON.parse(match[0]);
                } catch (e2) {
                    console.error("Double parse error", e2, "RAW:", text);
                }
            }
        }

        if (!json || !json.predictions) {
            return res.status(500).json({
                error: "Unexpected AI JSON format",
                raw: text
            });
        }


        res.json(json);

    } catch (err) {
        console.error(err?.response?.data ?? err.message);
        res.status(500).json({
            error: "AI error",
            detail: err?.response?.data ?? err.message
        });
    }
});


/*
POST /api/ai/kittl-phrases
Body: { niche, style }
Response:
{
  "phrases": [
    {
      "text": "",
      "typography": [],
      "colors": [],
      "layout": ""
    }
  ]
}
*/
app.post("/api/ai/kittl-phrases", async (req, res) => {
    try {
        const { niche = "", style = "" } = req.body;

        const system = `
You are an expert POD designer and Kittl typography specialist.
Always output JSON only.
`;

        const user = `
Generate 15 Kittl-ready POD design phrases for:
niche: "${niche}"
style: "${style}"

Each phrase must include:
- "text": POD-friendly slogan
- "typography": array of recommended Kittl font styles
- "colors": array of hex color suggestions
- "layout": recommended layout style (badge, stacked, curved text, retro arch, circle emblem, etc)

Return JSON ONLY in this format:

{
  "phrases": [
    {
      "text": "",
      "typography": [],
      "colors": [],
      "layout": ""
    }
  ]
}
`;

        const data = await callOpenAI([
            { role: "system", content: system },
            { role: "user", content: user }
        ], 1200);

        let text = data.choices?.[0]?.message?.content ?? "";

        // clean
        text = text.replace(/```json/g, "").replace(/```/g, "").trim();

        const json = JSON.parse(text);

        res.json(json);

    } catch (err) {
        console.error(err?.response?.data ?? err.message);
        res.status(500).json({
            error: "AI error",
            detail: err?.response?.data ?? err.message
        });
    }
});


/*
POST /api/ai/design-style
Body: { phrase, niche }
Response:
{
  "style": {
    "typography": [],
    "fonts": [],
    "colors": [],
    "layout": "",
    "illustration": "",
    "texture": "",
    "products": []
  }
}
*/
app.post("/api/ai/design-style", async (req, res) => {
    try {
        const { phrase = "", niche = "" } = req.body;

        const system = `
You are an expert POD designer specializing in Kittl, Etsy bestsellers, 3D puff, vintage, kawaii, retro, and modern T-shirt layouts.
Always output JSON only.
`;

        const user = `
Generate a complete POD-ready design style for the following:
Phrase: "${phrase}"
Niche: "${niche}"

Return JSON exactly like this:
{
  "style": {
    "typography": ["retro bold", "script accent"],
    "fonts": ["Kittl Antique", "Sunday Retro", "Bebas Neue"],
    "colors": ["#FDC57B","#FF725E","#2B2D42"],
    "layout": "arched badge with center icon",
    "illustration": "retro sunset with horizontal stripes",
    "texture": "distressed vintage grain",
    "products": ["t-shirt","hoodie","sticker","tote bag"]
  }
}
`;

        const data = await callOpenAI([
            { role: "system", content: system },
            { role: "user", content: user }
        ], 1000);

        let text = data.choices?.[0]?.message?.content ?? "";
        text = text.replace(/```json|```/g, "").trim();

        res.send(JSON.parse(text));

    } catch (err) {
        console.error("AI Design Style Error:", err);
        res.status(500).json({
            error: "AI error",
            detail: err?.response?.data ?? err.message
        });
    }
});

/*
POST /api/ai/design-brief
Body: { phrase, niche }
Response:
{
  "brief": {
    "phrase": "",
    "style_direction": "",
    "font_pairing": [],
    "color_palette": [],
    "layout": "",
    "illustration": [],
    "texture": "",
    "products": [],
    "mockup_prompt": "",
    "seo_title": "",
    "tags": []
  }
}
*/
app.post("/api/ai/design-brief", async (req, res) => {
    try {
        const { phrase = "", niche = "" } = req.body;

        const briefSchema = {
            name: "DesignBrief",
            schema: {
                type: "object",
                properties: {
                    brief: {
                        type: "object",
                        properties: {
                            phrase: { type: "string" },
                            style_direction: { type: "string" },
                            font_pairing: { type: "array", items: { type: "string" } },
                            color_palette: { type: "array", items: { type: "string" } },
                            layout: { type: "string" },
                            illustration: { type: "array", items: { type: "string" } },
                            texture: { type: "string" },
                            products: { type: "array", items: { type: "string" } },
                            mockup_prompt: { type: "string" },
                            seo_title: { type: "string" },
                            tags: { type: "array", items: { type: "string" } },

                            example_designs: {
                                type: "array",
                                items: { type: "string" },
                                minItems: 6,
                                maxItems: 6
                            }
                        },
                        required: [
                            "phrase", "style_direction", "font_pairing", "color_palette",
                            "layout", "illustration", "texture", "products",
                            "mockup_prompt", "seo_title", "tags", "example_designs"
                        ]
                    }
                },
                required: ["brief"]
            }
        };


        // --------------------------
        // UPDATED STRONGER PROMPT
        // --------------------------

        const userPrompt = `
Create a COMPLETE print-on-demand design brief for the phrase:

"${phrase}"

────────────────────────────────
🎨 STYLE CONSISTENCY RULE (CRITICAL)
────────────────────────────────
- Select EXACTLY ONE primary style_direction.
- The style_direction MUST be a single cohesive aesthetic (no commas, no lists).
- This same style_direction must be used consistently across:
  • illustration
  • typography
  • color palette
  • example URLs
- Do NOT combine multiple styles.

You MUST choose EXACTLY ONE style_direction from the following approved POD styles.

Allowed style_direction values:
kawaii
cute cartoon
soft pastel
whimsical illustration
cozy illustration
vintage retro
retro 70s
retro 80s
retro 90s
distressed vintage
bold minimal
modern minimal
clean typography
playful typography
bold typography
handwritten typography
script typography
stacked typography
retro typography
cute illustration
line art illustration
flat illustration
vector illustration
cartoon illustration
hand-drawn illustration
streetwear
grunge streetwear
urban graphic
bold graphic
boho
hipster
punk
gothic
earthy aesthetic
organic minimal
nature inspired
holiday festive
christmas vintage
halloween spooky
valentine cute

DO NOT invent new styles.
DO NOT combine styles.
DO NOT use commas.


INVALID examples:
"kawaii, playful, cheerful"
"retro + modern"
"cute and funny"

────────────────────────────────
🔗 EXAMPLE DESIGN URL REQUIREMENTS
────────────────────────────────
You MUST generate EXACTLY **6 highly relevant example design URLs**, one from EACH source below:

1. Pinterest  
2. Kittl  
3. Google Images  
4. Dribbble  
5. Behance  
6. Redbubble  

Each URL MUST be a REAL, WORKING search URL that clearly reflects:
- the phrase
- the chosen style_direction
- the illustration approach
- the POD product category
- the color mood

Each URL query MUST include:
- the phrase
- the style_direction
- ONE POD product (t-shirt, hoodie, sticker, mug, or poster)
- ONE or TWO HEX colors from the color palette

DO NOT invent random keywords.
DO NOT generalize.
DO NOT output generic searches.

────────────────────────────────
🔗 REQUIRED URL FORMATS
────────────────────────────────

Pinterest:
https://www.pinterest.com/search/pins/?q=<phrase> <style_direction> <product> <hex_color>

Kittl:
https://www.kittl.com/search?q=<phrase> <style_direction>

Google Images:
https://www.google.com/search?tbm=isch&q=<phrase> <style_direction> <product> <hex_color>

Dribbble:
https://dribbble.com/search/<phrase>-<style_direction>

Behance:
https://www.behance.net/search?search=<phrase> <style_direction> <hex_color>

Redbubble:
https://www.redbubble.com/shop/?query=<phrase> <style_direction> <product> <hex_color>

────────────────────────────────
🚫 STRICT RULES (DO NOT BREAK)
────────────────────────────────
- Output ONLY valid JSON that follows the schema EXACTLY.
- example_designs MUST contain EXACTLY 6 URLs (no more, no less).
- URLs must be realistic, relevant, and stylistically aligned.
- No placeholder text.
- No explanations.
- No markdown.
- No extra commentary.
- All HEX colors must be valid (#RRGGBB).

        `;



        // --------------------------
        // OPENAI CALL
        // --------------------------

        const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            response_format: {
                type: "json_schema",
                json_schema: briefSchema
            },
            messages: [
                { role: "system", content: "You produce ultra-precise POD design briefs with highly relevant inspiration URLs." },
                { role: "user", content: userPrompt }
            ],
            temperature: 0.35,
            max_tokens: 2000
        });

        const json = response.choices[0].message.content;
        res.json(JSON.parse(json));

    } catch (err) {
        console.error("Design Brief Error:", err);
        res.status(500).json({
            error: "AI error",
            detail: err?.response?.data ?? err.message
        });
    }
});




import fs from "fs";

app.post("/save-brief", (req, res) => {
    const { filename, content } = req.body;

    const folder = path.join(process.cwd(), "briefing");
    if (!fs.existsSync(folder)) fs.mkdirSync(folder);

    const filepath = path.join(folder, filename);
    fs.writeFileSync(filepath, JSON.stringify(content, null, 2));

    res.json({ saved: true, path: filepath });
});


app.post("/api/ai/trend-pack", async (req, res) => {
    try {
        const { trend = "" } = req.body;
        const today = new Date().toISOString().split("T")[0];

        const packSchema = {
            name: "DesignPackPerPhrase",
            schema: {
                type: "object",
                properties: {
                    pack: {
                        type: "object",
                        properties: {
                            trend: { type: "string" },

                            // top-level example url buckets
                            example_urls: {
                                type: "object",
                                properties: {
                                    pinterest: { type: "array", items: { type: "string" } },
                                    kittl: { type: "array", items: { type: "string" } },
                                    freepik: { type: "array", items: { type: "string" } },
                                    etsy: { type: "array", items: { type: "string" } }
                                },
                                required: ["pinterest", "kittl", "freepik", "etsy"]
                            },

                            // designs array (5 per pack)
                            designs: {
                                type: "array",
                                minItems: 5,
                                maxItems: 5,
                                items: {
                                    type: "object",
                                    properties: {
                                        phrase: { type: "string" },

                                        brand_style: {
                                            type: "object",
                                            properties: {
                                                keywords: { type: "array", items: { type: "string" } },
                                                mood: { type: "string" },
                                                visual_identity: { type: "string" },
                                                lighting: { type: "string" },
                                                restrictions: { type: "array", items: { type: "string" } }
                                            },
                                            required: ["keywords", "mood", "visual_identity"]
                                        },

                                        typography_system: {
                                            type: "object",
                                            properties: {
                                                primary: { type: "string" },
                                                secondary: { type: "string" },
                                                display: { type: "string" },
                                                rules: { type: "array", items: { type: "string" } }
                                            },
                                            required: ["primary", "secondary"]
                                        },

                                        color_system: {
                                            type: "object",
                                            properties: {
                                                primary: { type: "array", items: { type: "string" } },
                                                secondary: { type: "array", items: { type: "string" } },
                                                accent: { type: "array", items: { type: "string" } },
                                                avoid: { type: "array", items: { type: "string" } }
                                            },
                                            required: ["primary", "secondary"]
                                        },

                                        illustration_system: {
                                            type: "object",
                                            properties: {
                                                style: { type: "string" },
                                                stroke_weight: { type: "string" },
                                                shading: { type: "string" },
                                                allowed_elements: { type: "array", items: { type: "string" } },
                                                forbidden_elements: { type: "array", items: { type: "string" } }
                                            },
                                            required: ["style", "allowed_elements"]
                                        },

                                        layout_system: {
                                            type: "object",
                                            properties: {
                                                patterns: { type: "array", items: { type: "string" } },
                                                spacing_rules: { type: "string" },
                                                hierarchy: { type: "string" },
                                                safe_area: { type: "string" },
                                                grid: { type: "string" }
                                            },
                                            required: ["patterns"]
                                        },

                                        texture_system: {
                                            type: "object",
                                            properties: {
                                                allowed: { type: "array", items: { type: "string" } },
                                                forbidden: { type: "array", items: { type: "string" } },
                                                effect_level: { type: "string" }
                                            }
                                        },

                                        mockup_system: {
                                            type: "object",
                                            properties: {
                                                camera: { type: "string" },
                                                lighting: { type: "string" },
                                                background: { type: "string" },
                                                prompts: { type: "array", items: { type: "string" } }
                                            },
                                            required: ["prompts"]
                                        },

                                        product_guidelines: {
                                            type: "object",
                                            properties: {
                                                tshirt: { type: "string" },
                                                hoodie: { type: "string" },
                                                sticker: { type: "string" },
                                                mug: { type: "string" },
                                                poster: { type: "string" },
                                                tote: { type: "string" }
                                            },
                                            required: ["tshirt"]
                                        },

                                        seo: {
                                            type: "object",
                                            properties: {
                                                title: { type: "string" },
                                                tags: { type: "array", items: { type: "string" } },
                                                short_description: { type: "string" },
                                                long_description: { type: "string" }
                                            },
                                            required: ["title", "tags"]
                                        },

                                        example_urls: {
                                            type: "object",
                                            properties: {
                                                pinterest: { type: "array", items: { type: "string" } },
                                                kittl: { type: "array", items: { type: "string" } },
                                                freepik: { type: "array", items: { type: "string" } },
                                                etsy: { type: "array", items: { type: "string" } }
                                            },
                                            required: ["pinterest", "kittl", "freepik", "etsy"]
                                        }
                                    },
                                    required: [
                                        "phrase",
                                        "brand_style",
                                        "typography_system",
                                        "color_system",
                                        "illustration_system",
                                        "layout_system",
                                        "mockup_system",
                                        "product_guidelines",
                                        "seo",
                                        "example_urls"
                                    ]
                                }
                            }
                        },
                        required: ["trend", "example_urls", "designs"]
                    }
                },
                required: ["pack"]
            }
        };

        const userPrompt = `
 Today's date: ${today}

Create a complete design pack for the trend: "${trend}".

Produce exactly 5 distinct design systems, each based on a unique phrase.  
All output must strictly follow the JSON schema.  
No extra fields. No missing fields. No commentary.

-----------------------------
URL GENERATION REQUIREMENTS
-----------------------------

For both:
• pack.example_urls  
AND  
• each design.example_urls  

You must generate fully formed, real search URLs.

Every URL must include:
- the phrase
- a design style (retro, kawaii, minimal, vintage, grunge, bold, etc.)
- a POD product keyword (“tshirt”, “hoodie”, “mug”, “sticker”, “poster”)
- one or two HEX color codes from the design palette

All URLs must be valid, query-based links.  
Do NOT produce placeholders or empty arrays.

Use these URL formats:

Pinterest:
https://www.pinterest.com/search/pins/?q=<phrase> <style> <product> <color>

Kittl:
https://www.kittl.com/search?q=<phrase> <style>

Google Images:
https://www.google.com/search?tbm=isch&q=<phrase> <style> <product> <color>

Freepik:
https://www.freepik.com/search?query=<phrase> <style>

Etsy:
https://www.etsy.com/search?q=<phrase> <product> <style>

Redbubble:
https://www.redbubble.com/shop/?query=<phrase> <product> <style> <color>

Rules:
- Never include angle brackets (< >) in the final output.
- Replace <phrase>, <style>, <product>, <color> with real values.
- All colors must be valid #RRGGBB hex codes.

-----------------------------
DESIGN SYSTEM FIELDS REQUIRED
-----------------------------

Each design must include:

brand_style:
- keywords
- mood
- visual_identity
- lighting
- restrictions

typography_system:
- primary
- secondary
- display
- rules

color_system:
- primary (4–6 hex)
- secondary (2–4 hex)
- accent
- avoid

illustration_system:
- style
- stroke_weight
- shading
- allowed_elements
- forbidden_elements

layout_system:
- patterns
- spacing_rules
- hierarchy
- safe_area
- grid

texture_system:
- allowed
- forbidden
- effect_level

mockup_system:
- camera: Describe the cinematic lens, angle and depth (e.g., “35mm lens, shallow DOF, warm commercial perspective”)
- lighting: Rich atmospheric lighting appropriate to the scene (golden hour glow, soft studio diffusion, neon rim light, natural window light)
- background: Immersive, visually expressive setting that enhances the product (rooftop at sunset, cozy bedroom, minimal studio, lively street backdrop)
- prompts (exactly 3):
    • Prompt 1 MUST be a lifestyle mockup featuring a real human wearing or using the POD product (e.g., wearing the t-shirt, holding the mug, carrying the tote bag).  
      Include cinematic emotion, pose, vibe, and environment.
    • Prompt 2 MUST be a clean commercial studio mockup highlighting product details (fabric texture, print clarity, shape).
    • Prompt 3 MUST be a creative or aesthetic scene (flat lay, stylized product-only setup, color-themed environment, or dramatic lighting composition).


product_guidelines:
- tshirt
- hoodie
- sticker
- mug
- poster
- tote

seo:
- title
- tags (7–13)
- short_description
- long_description

example_urls:
- pinterest (3)
- kittl (2)
- freepik (2)
- etsy (2)
- redbubble (2)
- google (2)

-----------------------------
STRICT JSON OUTPUT RULES
-----------------------------

- Output only JSON following the schema.
- Escape all special characters properly.
- No trailing commas.
- No comments.
- No line breaks that break JSON.
- No unescaped quotes.
- Do not wrap output in backticks.

Return ONLY:
{
  "pack": { ... }
}`;

        const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            response_format: {
                type: "json_schema",
                json_schema: packSchema
            },
            messages: [
                {
                    role: "system",
                    content:
                        "You are an expert POD design director. Produce strict JSON that matches the schema exactly. No commentary."
                },
                {
                    role: "user",
                    content: userPrompt
                }
            ],
            temperature: 0.35,
            max_tokens: 4000
        });

        const jsonText = response.choices?.[0]?.message?.content;
        const parsed = JSON.parse(jsonText);
        return res.json(parsed);
    } catch (err) {
        console.error("Trend Pack Error:", err);
        res.status(500).json({
            error: "AI error",
            detail: err?.response?.data ?? err?.message ?? String(err)
        });
    }
});


app.post("/api/ai/evaluate-ideas", async (req, res) => {
    try {
        const { ideas = [], niche = "" } = req.body;

        if (!Array.isArray(ideas) || ideas.length === 0) {
            return res.status(400).json({ error: "No ideas provided." });
        }

        const evalSchema = {
            name: "IdeaEvaluationChunk",
            schema: {
                type: "object",
                properties: {
                    results: {
                        type: "array",
                        items: {
                            type: "object",
                            properties: {
                                text: { type: "string" },
                                score: { type: "number" },
                                label: {
                                    type: "string",
                                    enum: ["RECOMMENDED", "RISKY", "OUTDATED"]
                                },
                                signals: {
                                    type: "array",
                                    items: {
                                        type: "string",
                                        enum: [
                                            "high buyer intent",
                                            "low buyer intent",
                                            "oversaturated niche",
                                            "seasonal demand",
                                            "evergreen demand",
                                            "trademark risk",
                                            "strong gift appeal",
                                            "weak emotional appeal",
                                            "emerging trend",
                                            "declining trend"
                                        ]
                                    },
                                    minItems: 1,
                                    maxItems: 3
                                }
                            },
                            required: ["text", "score", "label", "signals"]
                        }
                    }
                },
                required: ["results"]
            }
        };

        // 🔹 Chunk helper
        const chunk = (arr, size) =>
            Array.from({ length: Math.ceil(arr.length / size) }, (_, i) =>
                arr.slice(i * size, i * size + size)
            );

        const chunks = chunk(ideas, 6); // 👈 SAFE SIZE
        let finalResults = [];

        for (const group of chunks) {
            const prompt = `
                You are a Print-on-Demand market evaluator.
                
                Evaluate EACH phrase for the niche "${niche}".
                
                PHRASES:
                ${group.map((x, i) => `${i + 1}. ${x}`).join("\n")}
                
                STRICT RULES:
                - Return EXACTLY one result per phrase
                - Preserve phrase text EXACTLY
                - Score from 0 to 100
                - RECOMMENDED: score ≥ 70
                - RISKY: score 40–69
                - OUTDATED: score < 40
                - Select 1–3 signals ONLY from the allowed list
                - NO explanations
                - JSON ONLY
                `;

            let parsed = null;

            for (let attempt = 0; attempt < 2; attempt++) {
                const response = await openai.chat.completions.create({
                    model: "gpt-4o-mini",
                    response_format: {
                        type: "json_schema",
                        json_schema: evalSchema
                    },
                    messages: [
                        {
                            role: "system",
                            content:
                                "Return strict JSON only. Do not add commentary."
                        },
                        { role: "user", content: prompt }
                    ],
                    temperature: 0.1,
                    max_tokens: 700
                });

                const raw = response.choices?.[0]?.message?.content || "";

                try {
                    parsed = JSON.parse(raw);
                    break;
                } catch {
                    if (attempt === 1) {
                        throw new Error("Chunk evaluation failed");
                    }
                }
            }

            finalResults.push(...parsed.results);
        }

        return res.json({ results: finalResults });

    } catch (err) {
        console.error("Idea Evaluation Error:", err);
        return res.status(500).json({
            error: "AI error",
            detail: err.message || "Evaluation failed"
        });
    }
});







app.post("/api/ai/design-prompt", async (req, res) => {
    try {
        const {
            phrase,
            style_direction,
            font_pairing,
            color_palette,
            layout,
            illustration,
            texture,
            products,
            mockup_prompt,
            seo_title,
            tags
        } = req.body;

        if (!phrase) {
            return res.status(400).json({ error: "Missing phrase" });
        }

        const promptSchema = {
            name: "DesignPrompt",
            schema: {
                type: "object",
                properties: {
                    prompt: { type: "string" }
                },
                required: ["prompt"]
            }
        };

        const userPrompt = `
Create ONE highly descriptive, production-ready design prompt for a Print-on-Demand graphic.

The prompt must describe ONLY the artwork/design itself — not a mockup scene, environment, room, people, or background context.

Use this information:

Phrase: "${phrase}"
Style Direction: The design style is ${style_direction} , with a strong visual identity that feels intentional, cohesive, and commercially ready for POD platforms.
Font Pairing: Use ${font_pairing} as the primary font system, with clear hierarchy, confident letterforms, and balanced spacing. Emphasize key words using scale, weight, and contrast to guide the viewer’s eye naturally across the phrase. Typography should feel bold, readable, and emotionally expressive.
Color Palette: Apply a refined color palette using ${color_palette}  Colors should feel harmonious and purpose-driven, supporting the emotional tone without overpowering the typography. Maintain strong contrast for print clarity and avoid muddy or low-contrast combinations.
Layout: Use a ${layout} composition with balanced negative space. The phrase must remain the focal point at all times. The design should feel centered, stable, and well-proportioned when placed on apparel or merchandise.
Illustration Elements: Incorporate ${illustration} as supporting visual elements, not distractions. Illustrations should enhance the meaning of the phrase, framing or interacting with the typography in a playful but controlled way. Keep shapes clean, vector-style, and suitable for large-scale printing.
Texture Feel: Introduce ${texture} texture subtly to add depth and tactility without reducing sharpness. The final result should look crisp, clean, and premium when printed.
Target Products: ${products}

DESIGN PROMPT RULES:
- Focus strictly on the graphic composition that will be printed on the product
- Describe typography hierarchy, font personality, and lettering behavior
- Background must be plain and solid or transparent, contrasting with the design so it can be remove easily by AI tools
- Describe illustration style, shapes, line quality, and decorative elements
- Mention color relationships, contrast, and balance
- Mention texture ONLY as a surface or visual treatment (e.g. soft, grainy, fluffy, smooth)
- Do NOT describe any background scene, setting, environment, lifestyle, or photography
- Do NOT mention models, people, rooms, tables, walls, or lighting setups
- Assume a transparent or plain background suitable for printing
- Write as one rich, cohesive paragraph
- Cinematic, vivid, and design-focused language
- Suitable for Kittl, vector illustration tools, and POD artwork creation
- No bullet points
- No explanations
- No JSON
- Output ONLY the final prompt text
Output quality:
High-quality vector illustration style, clean edges, bold graphic design, print-ready, commercial POD artwork, sharp lines, balanced composition, professional typography, modern aesthetic, 4K-level detail.


  `;

        const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            response_format: {
                type: "json_schema",
                json_schema: promptSchema
            },
            messages: [
                { role: "system", content: "You are an expert creative director for POD design prompts." },
                { role: "user", content: userPrompt }
            ],
            temperature: 0.6,
            max_tokens: 600
        });

        const json = response.choices[0].message.content;
        res.json(JSON.parse(json));

    } catch (err) {
        console.error("Design Prompt Error:", err);
        res.status(500).json({
            error: "AI error",
            detail: err?.message
        });
    }
});



app.get('/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`AI proxy server running on ${PORT}`));
