console.log("🧩 Artistly content script loaded");



// GLOBAL automation controller


window.AUTOMATION = {
    cancel: false,
    runId: 0
};

window.stopAutomation = () => {
    console.log("⛔ Stopping all automation");
    window.AUTOMATION.cancel = true;
};


function guard(runId) {
    if (window.AUTOMATION.cancel || window.AUTOMATION.runId !== runId) {
        console.warn("⏹ Automation aborted (safe)");
        throw new Error("Automation cancelled (safe)");
    }
}



// ==============================
// Utilities (DECLARE ONCE)
// ==============================
// define only once, safely
if (typeof window.sleep === "undefined") {
    window.sleep = ms =>
        new Promise(r => setTimeout(r, ms));
}

if (typeof window.waitFor === "undefined") {
    window.waitFor = async (fn, label, timeout = 10000, runId = null) => {
        const start = Date.now();

        while (true) {

            // Only guard if runId is explicitly provided
            if (runId !== null) {
                guard(runId);
            }

            try {
                const el = fn();
                if (el) return el;
            } catch { }

            if (Date.now() - start > timeout) {
                throw new Error("Timeout waiting for " + label);
            }

            await window.sleep(300);
        }
    };
}



// ==============================
// Click Create From Prompt (ICON)
// ==============================
async function clickCreateFromPrompt() {
    const icon = await waitFor(
        () => {
            const label = [...document.querySelectorAll("div")]
                .find(d =>
                    d.textContent &&
                    d.textContent.replace(/\s+/g, " ").trim() === "Create From Prompt"
                );

            if (!label) return null;

            const group = label.closest(".group");
            if (!group) return null;

            return group.querySelector("svg")?.parentElement || null;
        },
        "Create From Prompt icon"
    );

    icon.scrollIntoView({ block: "center" });
    await sleep(300);

    ["pointerdown", "mousedown", "mouseup", "click"].forEach(type => {
        icon.dispatchEvent(
            new MouseEvent(type, {
                bubbles: true,
                cancelable: true,
                view: window
            })
        );
    });

    console.log("✅ Clicked Create From Prompt");
}

// ==============================
// DESIGN PROMPT AUTOMATION
// ==============================
async function runArtistlyAutomation(prompt) {
    if (!prompt) throw new Error("Missing prompt");

    console.log("🚀 Running design prompt automation");

    // 1️⃣ Create From Prompt
    await clickCreateFromPrompt();
    await sleep(800);

    // 2️⃣ Inject prompt
    const textarea = await waitFor(
        () => document.querySelector('textarea[placeholder="Enter prompt here"]'),
        "Prompt textarea"
    );

    textarea.focus();
    textarea.value = prompt;
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
    console.log("✍️ Prompt injected");

    // 3️⃣ Quantity → 4
    const qty = await waitFor(
        () => [...document.querySelectorAll("select")].find(s => s.value === "1"),
        "Quantity select"
    );

    qty.value = "4";
    qty.dispatchEvent(new Event("change", { bubbles: true }));
    console.log("🔢 Quantity set to 4");

    // 4️⃣ High Quality
    const hqBtn = await waitFor(
        () => [...document.querySelectorAll("button")].find(b => b.textContent?.trim() === "High Quality"),
        "High Quality button"
    );
    hqBtn.click();

    // 5️⃣ Generate
    const genBtn = await waitFor(
        () => document.getElementById("generate_image_flux"),
        "Generate button"
    );
    genBtn.click();

    console.log("🎨 Image generation started");
}

// ==============================
// MOCKUP AUTOMATION (ETSY FLOW)
// ==============================
async function runMockupAutomation(prompt) {
    try {
        console.log("🚀 Running mockup automation");

        // 1️⃣ AI Design Assistants
        const aiAssist = await waitFor(
            () => {
                const container = document.getElementById("AI Design Assistants3");
                if (!container) return null;

                return container.querySelector("a");
            },
            "AI Design Assistants container"
        );

        aiAssist.scrollIntoView({ block: "center" });
        aiAssist.click();

        await sleep(1500);

        // 2️⃣ Mockup Creator
        const mockupCard = await waitFor(
            () => {
                const label = [...document.querySelectorAll("div")]
                    .find(d =>
                        d.textContent &&
                        d.textContent.replace(/\s+/g, " ").trim() === "Mockup Creator"
                    );

                if (!label) return null;

                const group = label.closest(".group");
                if (!group) return null;

                return group.querySelector("div.relative");
            },
            "Mockup Creator card"
        );

        // Real user-like click
        mockupCard.scrollIntoView({ block: "center" });

        ["pointerdown", "mousedown", "mouseup", "click"].forEach(type => {
            mockupCard.dispatchEvent(
                new MouseEvent(type, {
                    bubbles: true,
                    cancelable: true,
                    view: window
                })
            );
        });
        await sleep(2000);

        // 3️⃣ Wait for uploaded design
        await waitFor(
            () => document.querySelector(".filepond--image-preview canvas"),
            "Uploaded design preview"
        );

        // 4️⃣ Quantity → 4
        const qty = await waitFor(
            () => [...document.querySelectorAll("select")].find(s => s.value === "1"),
            "Mockup quantity select"
        );
        qty.value = "4";
        qty.dispatchEvent(new Event("change", { bubbles: true }));

        // 5️⃣ Prompt
        const textarea = await waitFor(
            () =>
                document.querySelector(
                    'textarea[placeholder="Example: Photo of woman wearing t-shirt, t-shirt has a logo on it"]'
                ),
            "Mockup prompt textarea"
        );

        textarea.focus();
        textarea.value = prompt;
        textarea.dispatchEvent(new Event("input", { bubbles: true }));

        // 6️⃣ Generate
        const genBtn = await waitFor(
            () => document.getElementById("generate_image_flux"),
            "Generate mockup button"
        );
        genBtn.click();

        console.log("🎉 Mockup generation started");

    } catch (err) {
        console.error("❌ Mockup automation failed:", err);
        alert("Mockup automation failed:\n" + err.message);
    }
}



async function openDesigner() {
    window.location.href = "https://app.artistly.ai/ai/image-designer-v6";
    await sleep(2000);
}

async function clickTextButton(text) {
    const btn = await waitFor(
        () =>
            [...document.querySelectorAll("button, div, span")]
                .find(b => b.textContent?.trim() === text),
        `Button: ${text}`
    );

    btn.scrollIntoView({ block: "center" });

    ["pointerdown", "mousedown", "mouseup", "click"].forEach(type => {
        btn.dispatchEvent(
            new MouseEvent(type, {
                bubbles: true,
                cancelable: true,
                view: window
            })
        );
    });

    await sleep(600);
}


function whenReady() {
    return new Promise(res => {
        if (document.readyState === "complete") return res();
        window.addEventListener("load", () => res(), { once: true });
    });
}

window.safeWaitFor = async (fn, label, timeout = 20000, runId = null) => {
    try {
        return await window.waitFor(fn, label, timeout, runId);
    } catch (e) {
        console.warn("Ignoring wait error:", label, e.message);
        return null;   // <- continue automation instead of crashing
    }
};


// ==============================
// MESSAGE HANDLERS (ONLY ONCE)
// ==============================

if (!window.__ARTISTLY_LISTENER__) {
    window.__ARTISTLY_LISTENER__ = true;

    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        if (msg.type === "RUN_ARTISTLY_AUTOMATION") {
            runArtistlyAutomation(msg.prompt)
                .then(() => sendResponse({ ok: true }))
                .catch(err => sendResponse({ error: String(err) }));
            return true;
        }

        if (msg.type === "RUN_ARTISTLY_MOCKUP_AUTOMATION") {
            console.log("🚀 Running mockup automation 1");
            runMockupAutomation(msg.prompt)
                .then(() => sendResponse({ ok: true }))
                .catch(err => sendResponse({ error: String(err) }));
            return true;
        }

        if (msg.type === "RUN_ARTISTLY_CLONE") {
            console.log("🚀 Running clone automation 2");

            (async () => {

                // stop running automations
                window.AUTOMATION.cancel = true;

                await sleep(2000);

                // allow automation again
                window.AUTOMATION.cancel = false;

                const runId = ++window.AUTOMATION.runId;

                try {
                    guard(runId);
                    await whenReady(runId);

                    // wait for that annoying error script to finish loading
                    await waitForAnnoyingErrorThenContinue();
                    await clickCreateFromPrompt(runId);
                    await clickTextButton("Mirror Magic");

                    const canvas = await safeWaitFor(
                        () => document.querySelector(".filepond--image-preview canvas"),
                        "Mirror Magic canvas",
                        20000,
                        runId
                    );

                    // If canvas missing, just continue
                    if (!canvas) {
                        console.log("⚠️ No Mirror Magic canvas detected, continuing anyway…");
                    }


                    const uploadDone = await waitFor(
                        () => {
                            const el = document.querySelector(".filepond--file-status-main");
                            if (!el) return null;

                            const visible =
                                el.offsetParent !== null &&
                                window.getComputedStyle(el).display !== "none" &&
                                window.getComputedStyle(el).visibility !== "hidden";

                            const txt = el.textContent.trim().toLowerCase();
                            return visible && txt.includes("upload complete") ? el : null;
                        },
                        "Visible upload-complete status"
                    );

                    console.log("✅ Image uploaded:", canvas, uploadDone);
                    await sleep(300);

                    await clickDescribeButton();

                    const extracted = await waitFor(
                        () => {
                            const label = [...document.querySelectorAll("p")]
                                .find(p => p.textContent?.trim() === "Extracted Prompt");
                            return label?.parentElement?.querySelector("textarea") || null;
                        },
                        "Extracted prompt textarea", 50000, runId
                    );

                    await navigator.clipboard.writeText(extracted.value);
                    await clickTextButton("Use Prompt");
                    console.log("✨ Extracted prompt copied");

                    chrome.runtime.sendMessage(
                        {
                            type: "CLONE_RESULT",
                            payload: extracted.value
                        },
                        resp => {
                            console.log("📥 Background responded:", resp, chrome.runtime.lastError);
                        }
                    );

                    sendResponse({ ok: true });
                    guard(runId);

                } catch (err) {

                    if (String(err.message).includes("Automation cancelled")) {
                        console.log("⏸ Clone stopped intentionally. Not an error.");
                        sendResponse({ ok: true });
                        return;
                    }

                    console.error("Clone automation failed:", err);
                    sendResponse({ error: err.message });
                }
            })();

            return true;
        }


        function waitForAnnoyingErrorThenContinue(timeout = 1000) {
            return new Promise(resolve => {
                let done = false;

                const finish = () => {
                    if (done) return;
                    done = true;
                    window.removeEventListener("error", onErr, true);
                    resolve();
                };

                // Watch network / script load errors
                function onErr(e) {
                    const msg = String(e?.filename || e?.message || "").toLowerCase();

                    if (msg.includes("dtscout")) {
                        console.log("⚠️ Tracking script failed (safe to ignore)");
                        finish();
                    }
                }

                window.addEventListener("error", onErr, true);

                // Fallback: continue anyway after timeout
                setTimeout(finish, timeout);
            });
        }


        async function clickDescribeButton() {
            const btn = await waitFor(
                () =>
                    [...document.querySelectorAll('button[type="submit"]')]
                        .find(b =>
                            b.textContent?.trim().toLowerCase() === "describe"
                        ),
                "Describe submit button"
            );

            btn.scrollIntoView({ block: "center" });

            ["pointerdown", "mousedown", "mouseup", "click"].forEach(type => {
                btn.dispatchEvent(
                    new MouseEvent(type, {
                        bubbles: true,
                        cancelable: true,
                        view: window
                    })
                );
            });

            await sleep(400);
        }


        if (msg.type === "PASTE_CLONE_TO_APP") {
            const box = document.getElementById("variationInput");

            if (box) {
                box.value = msg.value;
                box.dispatchEvent(new Event("input", { bubbles: true }));

                console.log("✨ Clone text pasted into variationInput");
            }
        }

        if (msg.type === "RUN_ARTISTLY_STYLE_STEP1") {
            console.log("🎨 STEP 1: Click Illustrator");

            (async () => {
                const illustratorCard = await waitFor(
                    () => document.querySelector('div[id^="AI Art Illustrator"] a'),
                    "Illustrator link"
                );

                await clickNode(illustratorCard);
            })();

            return true;
        }


        if (msg.type === "RUN_ARTISTLY_STYLE_STEP2") {
            console.log("🎨 STEP 2: Fill + Generate");

            (async () => {
                const textarea = await waitFor(
                    () =>
                        [...document.querySelectorAll("textarea")]
                            .find(t => t.placeholder?.includes("Enter prompt here")),
                    "Prompt textarea"
                );

                textarea.value = msg.prompt;
                textarea.dispatchEvent(new Event("input", { bubbles: true }));

                const qty = await waitFor(
                    () =>
                        [...document.querySelectorAll("select")]
                            .find(s => [...s.options].some(o => o.value === "1")),
                    "Quantity select"
                );

                qty.value = "4";
                qty.dispatchEvent(new Event("change", { bubbles: true }));

                const btn = await waitFor(
                    () =>
                        [...document.querySelectorAll("button")]
                            .find(b => b.textContent?.trim() === "Generate Image"),
                    "Generate Button"
                );

                await clickNode(btn);

                console.log("🚀 Done generating images");
            })();

            return true;
        }




    });
}


async function clickNode(node) {
    ["pointerdown", "mousedown", "mouseup", "click"].forEach(e =>
        node.dispatchEvent(new MouseEvent(e, { bubbles: true }))
    );
}


